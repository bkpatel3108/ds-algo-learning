
public abstract class PassengerAbstractFactory {
	public abstract Passenger getFirstClassPassenger();
	public abstract Passenger getCoachPassenger();
}
