
public interface Position<T> {
	T getElement() throws IllegalStateException;
}
