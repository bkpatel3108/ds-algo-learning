package que.one.two;

public class CheckPermutationTest {

	public static void main(String[] args)
	{
		System.out.println(CheckPermutation.checkPermutation("abcdfga", "adae")); 
	}
}
